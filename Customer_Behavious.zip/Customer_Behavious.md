# Customer Behaviour Analysis

## Import Libraries 


```python
import pandas as pd
import numpy as np 
import seaborn as sns
import matplotlib.pyplot as plt 
import scipy as stats
```

## Upload and Read the Dataset


```python
df = pd.read_csv("C:/Users/sanji/OneDrive/Desktop/Customer Behaviours/shopping_trends.csv")
```


```python
df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer ID</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Item Purchased</th>
      <th>Category</th>
      <th>Purchase Amount (USD)</th>
      <th>Location</th>
      <th>Size</th>
      <th>Color</th>
      <th>Season</th>
      <th>Review Rating</th>
      <th>Subscription Status</th>
      <th>Payment Method</th>
      <th>Shipping Type</th>
      <th>Discount Applied</th>
      <th>Promo Code Used</th>
      <th>Previous Purchases</th>
      <th>Preferred Payment Method</th>
      <th>Frequency of Purchases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>55</td>
      <td>Male</td>
      <td>Blouse</td>
      <td>Clothing</td>
      <td>53</td>
      <td>Kentucky</td>
      <td>L</td>
      <td>Gray</td>
      <td>Winter</td>
      <td>3.1</td>
      <td>Yes</td>
      <td>Credit Card</td>
      <td>Express</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>14</td>
      <td>Venmo</td>
      <td>Fortnightly</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>19</td>
      <td>Male</td>
      <td>Sweater</td>
      <td>Clothing</td>
      <td>64</td>
      <td>Maine</td>
      <td>L</td>
      <td>Maroon</td>
      <td>Winter</td>
      <td>3.1</td>
      <td>Yes</td>
      <td>Bank Transfer</td>
      <td>Express</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>2</td>
      <td>Cash</td>
      <td>Fortnightly</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>50</td>
      <td>Male</td>
      <td>Jeans</td>
      <td>Clothing</td>
      <td>73</td>
      <td>Massachusetts</td>
      <td>S</td>
      <td>Maroon</td>
      <td>Spring</td>
      <td>3.1</td>
      <td>Yes</td>
      <td>Cash</td>
      <td>Free Shipping</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>23</td>
      <td>Credit Card</td>
      <td>Weekly</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>21</td>
      <td>Male</td>
      <td>Sandals</td>
      <td>Footwear</td>
      <td>90</td>
      <td>Rhode Island</td>
      <td>M</td>
      <td>Maroon</td>
      <td>Spring</td>
      <td>3.5</td>
      <td>Yes</td>
      <td>PayPal</td>
      <td>Next Day Air</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>49</td>
      <td>PayPal</td>
      <td>Weekly</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>45</td>
      <td>Male</td>
      <td>Blouse</td>
      <td>Clothing</td>
      <td>49</td>
      <td>Oregon</td>
      <td>M</td>
      <td>Turquoise</td>
      <td>Spring</td>
      <td>2.7</td>
      <td>Yes</td>
      <td>Cash</td>
      <td>Free Shipping</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>31</td>
      <td>PayPal</td>
      <td>Annually</td>
    </tr>
  </tbody>
</table>
</div>



## Clean and Prepare the Data


```python
df.isnull().sum()
```




    Customer ID                 0
    Age                         0
    Gender                      0
    Item Purchased              0
    Category                    0
    Purchase Amount (USD)       0
    Location                    0
    Size                        0
    Color                       0
    Season                      0
    Review Rating               0
    Subscription Status         0
    Payment Method              0
    Shipping Type               0
    Discount Applied            0
    Promo Code Used             0
    Previous Purchases          0
    Preferred Payment Method    0
    Frequency of Purchases      0
    dtype: int64



## Understanding the dataset


```python
df.dtypes
```




    Customer ID                   int64
    Age                           int64
    Gender                       object
    Item Purchased               object
    Category                     object
    Purchase Amount (USD)         int64
    Location                     object
    Size                         object
    Color                        object
    Season                       object
    Review Rating               float64
    Subscription Status          object
    Payment Method               object
    Shipping Type                object
    Discount Applied             object
    Promo Code Used              object
    Previous Purchases            int64
    Preferred Payment Method     object
    Frequency of Purchases       object
    dtype: object




```python
df.describe(include="all")
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer ID</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Item Purchased</th>
      <th>Category</th>
      <th>Purchase Amount (USD)</th>
      <th>Location</th>
      <th>Size</th>
      <th>Color</th>
      <th>Season</th>
      <th>Review Rating</th>
      <th>Subscription Status</th>
      <th>Payment Method</th>
      <th>Shipping Type</th>
      <th>Discount Applied</th>
      <th>Promo Code Used</th>
      <th>Previous Purchases</th>
      <th>Preferred Payment Method</th>
      <th>Frequency of Purchases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>3900.000000</td>
      <td>3900.000000</td>
      <td>3900</td>
      <td>3900</td>
      <td>3900</td>
      <td>3900.000000</td>
      <td>3900</td>
      <td>3900</td>
      <td>3900</td>
      <td>3900</td>
      <td>3900.000000</td>
      <td>3900</td>
      <td>3900</td>
      <td>3900</td>
      <td>3900</td>
      <td>3900</td>
      <td>3900.000000</td>
      <td>3900</td>
      <td>3900</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2</td>
      <td>25</td>
      <td>4</td>
      <td>NaN</td>
      <td>50</td>
      <td>4</td>
      <td>25</td>
      <td>4</td>
      <td>NaN</td>
      <td>2</td>
      <td>6</td>
      <td>6</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
      <td>6</td>
      <td>7</td>
    </tr>
    <tr>
      <th>top</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>Male</td>
      <td>Blouse</td>
      <td>Clothing</td>
      <td>NaN</td>
      <td>Montana</td>
      <td>M</td>
      <td>Olive</td>
      <td>Spring</td>
      <td>NaN</td>
      <td>No</td>
      <td>Credit Card</td>
      <td>Free Shipping</td>
      <td>No</td>
      <td>No</td>
      <td>NaN</td>
      <td>PayPal</td>
      <td>Every 3 Months</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2652</td>
      <td>171</td>
      <td>1737</td>
      <td>NaN</td>
      <td>96</td>
      <td>1755</td>
      <td>177</td>
      <td>999</td>
      <td>NaN</td>
      <td>2847</td>
      <td>696</td>
      <td>675</td>
      <td>2223</td>
      <td>2223</td>
      <td>NaN</td>
      <td>677</td>
      <td>584</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1950.500000</td>
      <td>44.068462</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>59.764359</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3.749949</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>25.351538</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1125.977353</td>
      <td>15.207589</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>23.685392</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.716223</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>14.447125</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>18.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>20.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.500000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>975.750000</td>
      <td>31.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>39.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3.100000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>13.000000</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1950.500000</td>
      <td>44.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>60.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3.700000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>25.000000</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2925.250000</td>
      <td>57.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>81.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4.400000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>38.000000</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>max</th>
      <td>3900.000000</td>
      <td>70.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>100.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>50.000000</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Skewness=Mean−Mode
skewness = (df["Purchase Amount (USD)"].mean() - df["Purchase Amount (USD)"].mode())
skewness
```




    0    27.764359
    1    23.764359
    2   -34.235641
    Name: Purchase Amount (USD), dtype: float64



## Exploratory Data Analysis (EDA)


```python
plt.figure(figsize=(10,4))
sns.histplot(df["Purchase Amount (USD)"], bins = 30, kde = True)
plt.title('Purchase Amount Distribution')
plt.xlabel('Purchase Amount (USD)')
plt.ylabel('Frequency')
plt.show()
```


    
![png](output_13_0.png)
    


### Analyze Spending by Category


```python
plt.figure(figsize=(10, 5))
sns.boxplot(x='Category', y='Purchase Amount (USD)', data=df)
plt.title('Spending by Category')
plt.xlabel('Product Category')
plt.ylabel('Purchase Amount (USD)')
plt.grid(True)
plt.show()
```


    
![png](output_15_0.png)
    


### Analyze Purchase Patterns by Category and Item
#### Determine the most popular 'Category' and 'Item Purchased' to identify top-selling products and product types.


```python
print("Most Popular Categories:")
print(df['Category'].value_counts())

print("\nMost Popular Items Purchased:")
print(df['Item Purchased'].value_counts())
```

    Most Popular Categories:
    Category
    Clothing       1737
    Accessories    1240
    Footwear        599
    Outerwear       324
    Name: count, dtype: int64
    
    Most Popular Items Purchased:
    Item Purchased
    Blouse        171
    Pants         171
    Jewelry       171
    Shirt         169
    Dress         166
    Sweater       164
    Jacket        163
    Coat          161
    Sunglasses    161
    Belt          161
    Sandals       160
    Socks         159
    Skirt         158
    Scarf         157
    Shorts        157
    Hat           154
    Handbag       153
    Hoodie        151
    Shoes         150
    T-shirt       147
    Sneakers      145
    Boots         144
    Backpack      143
    Gloves        140
    Jeans         124
    Name: count, dtype: int64
    

### Analyze Purchase Amounts
#### Explore the distribution of 'Purchase Amount (USD)' and analyze its relation to 'Category' to understand spending habits across different product types.


```python
print("\nAverage Purchase Amount (USD) by Category:")
print(df.groupby('Category')['Purchase Amount (USD)'].mean().sort_values(ascending=False))
```

    
    Average Purchase Amount (USD) by Category:
    Category
    Footwear       60.255426
    Clothing       60.025331
    Accessories    59.838710
    Outerwear      57.172840
    Name: Purchase Amount (USD), dtype: float64
    

### Visualize Customer Behavior


```python
# 1. Bar plot for Category Popularity
plt.figure(figsize=(10, 6))
sns.countplot(data=df, x='Category', order=df['Category'].value_counts().index, palette='viridis')
plt.title('Product Category Popularity')
plt.xlabel('Category')
plt.ylabel('Number of Purchases')
plt.show()

# 2. Histogram for Age Distribution
plt.figure(figsize=(10, 6))
sns.histplot(df['Age'], bins=10, kde=True, color='skyblue')
plt.title('Distribution of Customer Ages')
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.show()

# 3. Histogram for Purchase Amount (USD) Distribution
plt.figure(figsize=(10, 6))
sns.histplot(df['Purchase Amount (USD)'], bins=15, kde=True, color='lightcoral')
plt.title('Distribution of Purchase Amounts')
plt.xlabel('Purchase Amount (USD)')
plt.ylabel('Frequency')
plt.show()

# 4. Bar plot for Average Purchase Amount by Season
average_purchase_by_season = df.groupby('Season')['Purchase Amount (USD)'].mean().sort_values(ascending=False)
plt.figure(figsize=(10, 6))
sns.barplot(x=average_purchase_by_season.index, y=average_purchase_by_season.values, palette='plasma')
plt.title('Average Purchase Amount by Season')
plt.xlabel('Season')
plt.ylabel('Average Purchase Amount (USD)')
plt.show()
```

    C:\Users\sanji\AppData\Local\Temp\ipykernel_22328\2991811686.py:3: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(data=df, x='Category', order=df['Category'].value_counts().index, palette='viridis')
    


    
![png](output_21_1.png)
    



    
![png](output_21_2.png)
    



    
![png](output_21_3.png)
    


    C:\Users\sanji\AppData\Local\Temp\ipykernel_22328\2991811686.py:28: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x=average_purchase_by_season.index, y=average_purchase_by_season.values, palette='plasma')
    


    
![png](output_21_5.png)
    


### Gender-Based Purchase Comparison (Hypothesis Testing)
#### Testing if gender affects spending.


```python
from scipy import stats
import scipy.stats as stats
```


```python
#Group Data
male = df[df['Gender'] == 'Male']['Purchase Amount (USD)']
female = df[df['Gender'] == 'Female']['Purchase Amount (USD)']
```


```python
#Independent t-test
_, p_value = stats.ttest_ind(a=male, b=female,equal_var=False)
```


```python
if p_value < 0.05:
    print("That means gender affecting spending.")
else:
    print("That means gender doesn't affect spending.")
```

    That means gender doesn't affect spending.
    

### Correlation Analysis
#### Measure relationship between age & spending.


```python
df[['Age', 'Purchase Amount (USD)']].corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Purchase Amount (USD)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Age</th>
      <td>1.000000</td>
      <td>-0.010424</td>
    </tr>
    <tr>
      <th>Purchase Amount (USD)</th>
      <td>-0.010424</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.scatterplot(x='Age', y='Purchase Amount (USD)', data=df)
plt.title("Age vs Purchase Amount")
plt.show()
```


    
![png](output_29_0.png)
    

The plot shows NO CORRELATION between AGE & PURCHASE AMOUNT. The value -0.010124 is very close to zero, indicating that there is virtually no linear relationship between AGE & PURCHASE AMOUNT.
### Business Insights (MOST IMPORTANT)
#### Estimate true population mean.


```python
mean = df['Purchase Amount (USD)'].mean()
std = df['Purchase Amount (USD)'].std()
n = len(df)

confidence = 0.95
z = stats.norm.ppf(1 - (1 - confidence) / 2)

lower = mean - z * (std / np.sqrt(n))
upper = mean + z * (std / np.sqrt(n))

(lower, upper)
```




    (np.float64(59.021003799812476), np.float64(60.50771414890548))


We are 95% confident that the true average purchase amount of all customers in the population lies between $59.02 and $60.51.
This range was calculated using:
  Sample mean
  Sample standard deviation
  Sample size
  Z-score for 95% confidence
## Summary:
Data Analysis Key Findings

Data Quality: The dataset is complete with 3900 entries and no missing values across 19 columns, including customer demographics, purchase details, and product information.

Customer Demographics:
The customer base is predominantly male (2652 males vs. 1248 females).
Ages range from 18 to 70, with an average age of approximately 44 years and a median age of 44 years.

Purchase Amount Overview:
Purchase amounts range from $20 to $100, with an average of approximately $59.76 and a median of $60.00.
Review ratings are generally positive, averaging 3.75 out of 5.

Popular Products & Categories:
"Clothing" is the most popular category with 1737 purchases, followed by "Accessories" (1240 purchases).
"Blouse," "Pants," and "Jewelry" are the most frequently purchased individual items, each with 171 occurrences.

Spending by Category:
Average purchase amounts across categories are quite similar, hovering around $60.
"Footwear" has the highest average purchase amount ($60.26), while "Outerwear" has the lowest ($57.17).

Seasonal Trends:
"Spring" recorded the highest number of purchases (999), while "Summer" had the fewest (955).
"Fall" exhibits the highest average purchase amount ($61.56), whereas "Summer" shows the lowest ($58.41).

Locational Trends:
"Montana" had the highest number of purchases (96), while states like Kansas and Rhode Island had fewer (63 each).
"Alaska" boasts the highest average purchase amount ($67.60), significantly higher than "Connecticut" with the lowest average ($54.18).

Impact of Discounts and Subscriptions:
Neither applying a discount nor having a subscription significantly increases the average purchase amount. In fact, purchases without discounts ($60.13) and by non-subscribers ($59.87) showed marginally higher average spending compared to discounted purchases ($59.28) and subscribers ($59.49).